import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Search, ShoppingBag, Star, User, Ticket } from 'lucide-react';

const screenshots = [
  {
    id: 1,
    title: 'Explore Vendors',
    description: 'Browse nearby garages and auto services',
    icon: Search,
    color: 'from-blue-500 to-blue-600'
  },
  {
    id: 2,
    title: 'Bundle Details',
    description: 'View service packages and pricing',
    icon: ShoppingBag,
    color: 'from-green-500 to-green-600'
  },
  {
    id: 3,
    title: 'Vendor Profile',
    description: 'Check ratings, reviews, and info',
    icon: User,
    color: 'from-purple-500 to-purple-600'
  },
  {
    id: 4,
    title: 'Redeem Screen',
    description: 'Show QR code to redeem bundles',
    icon: Ticket,
    color: 'from-orange-500 to-orange-600'
  },
  {
    id: 5,
    title: 'Rate & Review',
    description: 'Share your service experience',
    icon: Star,
    color: 'from-yellow-500 to-yellow-600'
  }
];

const AppScreenshots: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % screenshots.length);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + screenshots.length) % screenshots.length);
  };

  const CurrentIcon = screenshots[currentIndex].icon;

  return (
    <section className="py-16 lg:py-24 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-5xl font-bold text-gray-900 mb-6">
            See Automoto in Action
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Take a peek at the clean, intuitive interface designed to make finding and booking auto services effortless.
          </p>
        </div>
        
        <div className="max-w-5xl mx-auto">
          {/* Mobile Carousel */}
          <div className="block lg:hidden">
            <div className="relative">
              <div className="flex items-center justify-center mb-8">
                <div className="w-64 h-80 bg-gray-900 rounded-3xl p-4 shadow-2xl">
                  <div className={`w-full h-full bg-gradient-to-br ${screenshots[currentIndex].color} rounded-2xl flex flex-col items-center justify-center text-white`}>
                    <CurrentIcon className="w-16 h-16 mb-4" />
                    <h3 className="text-lg font-semibold mb-2 text-center px-4">
                      {screenshots[currentIndex].title}
                    </h3>
                    <p className="text-sm text-center px-4 opacity-90">
                      {screenshots[currentIndex].description}
                    </p>
                  </div>
                </div>
              </div>
              
              {/* Navigation */}
              <div className="flex justify-center gap-4 mb-6">
                <button 
                  onClick={prevSlide}
                  className="p-3 bg-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 text-primary hover:bg-gray-50"
                >
                  <ChevronLeft className="w-6 h-6" />
                </button>
                <button 
                  onClick={nextSlide}
                  className="p-3 bg-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 text-primary hover:bg-gray-50"
                >
                  <ChevronRight className="w-6 h-6" />
                </button>
              </div>
              
              {/* Dots */}
              <div className="flex justify-center gap-2">
                {screenshots.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentIndex(index)}
                    className={`w-3 h-3 rounded-full transition-all duration-300 ${
                      index === currentIndex ? 'bg-primary' : 'bg-gray-300'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>
          
          {/* Desktop Grid */}
          <div className="hidden lg:grid grid-cols-5 gap-6">
            {screenshots.map((screenshot, index) => {
              const ScreenshotIcon = screenshot.icon;
              return (
                <div 
                  key={screenshot.id}
                  className="group cursor-pointer animate-slide-up"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className="w-full aspect-[3/4] bg-gray-900 rounded-3xl p-3 shadow-lg group-hover:shadow-2xl transition-all duration-300 transform group-hover:scale-105">
                    <div className={`w-full h-full bg-gradient-to-br ${screenshot.color} rounded-2xl flex flex-col items-center justify-center text-white`}>
                      <ScreenshotIcon className="w-12 h-12 mb-3" />
                      <h3 className="text-sm font-semibold mb-1 text-center px-2">
                        {screenshot.title}
                      </h3>
                      <p className="text-xs text-center px-2 opacity-90">
                        {screenshot.description}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default AppScreenshots;