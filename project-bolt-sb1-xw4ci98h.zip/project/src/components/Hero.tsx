import React from 'react';
import { Download, Smartphone, Car } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="relative bg-gradient-to-br from-primary via-primary-light to-primary-dark text-white overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-10 w-32 h-32 rounded-full bg-white/20 blur-xl"></div>
        <div className="absolute bottom-20 right-10 w-40 h-40 rounded-full bg-white/15 blur-2xl"></div>
      </div>
      
      <div className="relative container mx-auto px-4 py-16 lg:py-24">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          {/* Content */}
          <div className="flex-1 text-center lg:text-left animate-slide-up">
            <div className="flex items-center justify-center lg:justify-start gap-2 mb-6">
              <Car className="w-8 h-8 text-white" />
              <span className="text-lg font-medium">Automoto</span>
            </div>
            
            <h1 className="text-4xl lg:text-6xl font-bold mb-6 leading-tight">
              UAE's All-in-One
              <span className="block text-gray-200">Auto App</span>
            </h1>
            
            <p className="text-xl lg:text-2xl text-gray-200 mb-8 max-w-2xl">
              Discover garages, explore value bundles, and get access to trusted automobile services near you — all in one app.
            </p>
            
            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <button className="group bg-white text-primary px-8 py-4 rounded-xl font-semibold text-lg hover:bg-gray-50 transition-all duration-300 flex items-center justify-center gap-3 shadow-lg hover:shadow-xl transform hover:scale-105">
                <Download className="w-5 h-5" />
                Download on App Store
              </button>
              <button className="group bg-transparent border-2 border-white text-white px-8 py-4 rounded-xl font-semibold text-lg hover:bg-white hover:text-primary transition-all duration-300 flex items-center justify-center gap-3">
                <Download className="w-5 h-5" />
                Get it on Google Play
              </button>
            </div>
            
            <p className="text-gray-300 text-sm mt-6">
              Coming soon to iOS and Android
            </p>
          </div>
          
          {/* Phone Mockup */}
          <div className="flex-1 flex justify-center lg:justify-end animate-fade-in">
            <div className="relative">
              <div className="w-80 h-96 bg-gray-900 rounded-3xl p-4 shadow-2xl animate-float">
                <div className="w-full h-full bg-gradient-to-b from-gray-100 to-gray-200 rounded-2xl flex items-center justify-center">
                  <div className="text-center text-gray-600">
                    <Smartphone className="w-16 h-16 mx-auto mb-4" />
                    <p className="text-lg font-medium">Automoto App</p>
                    <p className="text-sm">Interface Preview</p>
                  </div>
                </div>
              </div>
              
              {/* Floating Icons */}
              <div className="absolute -top-4 -left-4 w-12 h-12 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center animate-float" style={{ animationDelay: '0.5s' }}>
                <Car className="w-6 h-6 text-white" />
              </div>
              <div className="absolute -bottom-4 -right-4 w-12 h-12 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center animate-float" style={{ animationDelay: '1s' }}>
                <Download className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;