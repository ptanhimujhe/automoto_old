import React from 'react';
import { Car, Instagram, Twitter, Facebook, Download } from 'lucide-react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="bg-primary text-white py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Main Footer Content */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
            {/* Brand */}
            <div className="lg:col-span-2">
              <div className="flex items-center gap-3 mb-6">
                <Car className="w-8 h-8" />
                <span className="text-2xl font-bold">Automoto</span>
              </div>
              <p className="text-gray-300 text-lg leading-relaxed mb-6 max-w-md">
                UAE's all-in-one auto app connecting drivers with trusted garages and service providers across the country.
              </p>
              
              {/* App Store Buttons */}
              <div className="flex flex-col sm:flex-row gap-4">
                <button className="group bg-white/10 border border-white/20 px-6 py-3 rounded-xl font-medium hover:bg-white/20 transition-all duration-300 flex items-center gap-3">
                  <Download className="w-5 h-5" />
                  App Store
                </button>
                <button className="group bg-white/10 border border-white/20 px-6 py-3 rounded-xl font-medium hover:bg-white/20 transition-all duration-300 flex items-center gap-3">
                  <Download className="w-5 h-5" />
                  Google Play
                </button>
              </div>
            </div>
            
            {/* Links */}
            <div>
              <h3 className="text-lg font-semibold mb-6">Company</h3>
              <ul className="space-y-3">
                <li>
                  <Link to="/terms" className="text-gray-300 hover:text-white transition-colors duration-300">
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link to="/privacy" className="text-gray-300 hover:text-white transition-colors duration-300">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <a href="#" className="text-gray-300 hover:text-white transition-colors duration-300">
                    Contact Us
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-300 hover:text-white transition-colors duration-300">
                    List Your Business
                  </a>
                </li>
              </ul>
            </div>
            
            {/* Contact & Social */}
            <div>
              <h3 className="text-lg font-semibold mb-6">Connect</h3>
              <div className="space-y-4 mb-6">
                <p className="text-gray-300">
                  <span className="block font-medium text-white">Email</span>
                  hello@automoto.ae
                </p>
                <p className="text-gray-300">
                  <span className="block font-medium text-white">Phone</span>
                  +971 XX XXX XXXX
                </p>
              </div>
              
              {/* Social Media */}
              <div className="flex gap-4">
                <a 
                  href="#" 
                  className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-all duration-300 transform hover:scale-110"
                >
                  <Instagram className="w-5 h-5" />
                </a>
                <a 
                  href="#" 
                  className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-all duration-300 transform hover:scale-110"
                >
                  <Twitter className="w-5 h-5" />
                </a>
                <a 
                  href="#" 
                  className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-all duration-300 transform hover:scale-110"
                >
                  <Facebook className="w-5 h-5" />
                </a>
              </div>
            </div>
          </div>
          
          {/* Bottom Bar */}
          <div className="border-t border-white/20 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <p className="text-gray-300 text-sm">
                © 2024 Automoto UAE. All rights reserved.
              </p>
              <p className="text-gray-400 text-sm">
                Made with ❤️ for UAE drivers
              </p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;