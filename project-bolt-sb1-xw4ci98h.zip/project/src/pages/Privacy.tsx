import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Car, Shield } from 'lucide-react';

const Privacy: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-3 text-primary hover:text-primary-light transition-colors">
              <ArrowLeft className="w-5 h-5" />
              <span>Back to Home</span>
            </Link>
            
            <div className="flex items-center gap-2">
              <Car className="w-6 h-6 text-primary" />
              <span className="font-bold text-primary">Automoto</span>
            </div>
          </div>
        </div>
      </header>
      
      {/* Content */}
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-2xl shadow-lg p-8 lg:p-12">
            <div className="flex items-center gap-4 mb-8">
              <Shield className="w-12 h-12 text-primary" />
              <h1 className="text-4xl lg:text-5xl font-bold text-gray-900">
                Privacy Policy
              </h1>
            </div>
            
            <div className="prose prose-lg max-w-none">
              <p className="text-xl text-gray-600 mb-8">
                Last updated: [Date to be added]
              </p>
              
              <div className="bg-primary/5 p-6 rounded-xl border-l-4 border-primary mb-8">
                <p className="text-gray-700 font-medium">
                  Your privacy is important to us. Automoto is committed to protecting your personal information and being transparent about how we collect, use, and share your data.
                </p>
              </div>
              
              <div className="space-y-8">
                <section>
                  <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                    1. Information We Collect
                  </h2>
                  <p className="text-gray-600 leading-relaxed mb-4">
                    [Content to be added by admin - This section will detail what personal information is collected, including:]
                  </p>
                  <ul className="list-disc list-inside text-gray-600 space-y-2 ml-4">
                    <li>Account registration information</li>
                    <li>Location data for nearby garage discovery</li>
                    <li>Payment information for bundle purchases</li>
                    <li>Usage data and app interactions</li>
                    <li>Device information and technical data</li>
                  </ul>
                </section>
                
                <section>
                  <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                    2. How We Use Your Information
                  </h2>
                  <p className="text-gray-600 leading-relaxed">
                    [Content to be added by admin - This section will explain how collected data is used to provide services, improve the app, and communicate with users.]
                  </p>
                </section>
                
                <section>
                  <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                    3. Information Sharing and Disclosure
                  </h2>
                  <p className="text-gray-600 leading-relaxed">
                    [Content to be added by admin - This section will outline when and how information is shared with third parties, including service providers and vendors.]
                  </p>
                </section>
                
                <section>
                  <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                    4. Data Security
                  </h2>
                  <p className="text-gray-600 leading-relaxed">
                    [Content to be added by admin - This section will describe security measures taken to protect user data and payment information.]
                  </p>
                </section>
                
                <section>
                  <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                    5. Your Rights and Choices
                  </h2>
                  <p className="text-gray-600 leading-relaxed">
                    [Content to be added by admin - This section will outline user rights regarding their personal data, including access, correction, and deletion rights.]
                  </p>
                </section>
                
                <section>
                  <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                    6. Location Services
                  </h2>
                  <p className="text-gray-600 leading-relaxed">
                    [Content to be added by admin - This section will specifically address location data collection and usage for garage discovery features.]
                  </p>
                </section>
                
                <section>
                  <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                    7. Children's Privacy
                  </h2>
                  <p className="text-gray-600 leading-relaxed">
                    [Content to be added by admin - This section will address privacy protections for users under 18 years of age.]
                  </p>
                </section>
                
                <section>
                  <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                    8. Changes to This Policy
                  </h2>
                  <p className="text-gray-600 leading-relaxed">
                    [Content to be added by admin - This section will explain how users will be notified of privacy policy updates.]
                  </p>
                </section>
                
                <section>
                  <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                    9. Contact Us
                  </h2>
                  <p className="text-gray-600 leading-relaxed mb-4">
                    If you have any questions or concerns about this Privacy Policy or our data practices, please contact us:
                  </p>
                  <div className="bg-gray-50 p-6 rounded-xl">
                    <p className="text-gray-700">
                      <strong>Privacy Officer</strong><br />
                      <strong>Email:</strong> privacy@automoto.ae<br />
                      <strong>Address:</strong> [To be added]<br />
                      <strong>Phone:</strong> [To be added]
                    </p>
                  </div>
                </section>
              </div>
              
              <div className="mt-12 p-6 bg-green-50 rounded-xl border-l-4 border-green-400">
                <p className="text-gray-700">
                  <strong>Commitment to Privacy:</strong> We are committed to maintaining the highest standards of privacy protection for all our users in the UAE. This policy will be fully detailed before our app launch.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Privacy;