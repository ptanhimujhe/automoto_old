import React from 'react';
import Hero from '../components/Hero';
import Features from '../components/Features';
import WhyAutomoto from '../components/WhyAutomoto';
import VendorInvitation from '../components/VendorInvitation';
import FAQ from '../components/FAQ';
import AppScreenshots from '../components/AppScreenshots';
import Footer from '../components/Footer';

const HomePage: React.FC = () => {
  return (
    <>
      <Hero />
      <Features />
      <WhyAutomoto />
      <VendorInvitation />
      <AppScreenshots />
      <FAQ />
      <Footer />
    </>
  );
};

export default HomePage;