import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Car } from 'lucide-react';

const Terms: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-3 text-primary hover:text-primary-light transition-colors">
              <ArrowLeft className="w-5 h-5" />
              <span>Back to Home</span>
            </Link>
            
            <div className="flex items-center gap-2">
              <Car className="w-6 h-6 text-primary" />
              <span className="font-bold text-primary">Automoto</span>
            </div>
          </div>
        </div>
      </header>
      
      {/* Content */}
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-2xl shadow-lg p-8 lg:p-12">
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-8">
              Terms of Service
            </h1>
            
            <div className="prose prose-lg max-w-none">
              <p className="text-xl text-gray-600 mb-8">
                Last updated: [Date to be added]
              </p>
              
              <div className="space-y-8">
                <section>
                  <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                    1. Acceptance of Terms
                  </h2>
                  <p className="text-gray-600 leading-relaxed">
                    [Content to be added by admin - This section will outline how users accept these terms by using the Automoto app and services.]
                  </p>
                </section>
                
                <section>
                  <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                    2. Description of Service
                  </h2>
                  <p className="text-gray-600 leading-relaxed">
                    [Content to be added by admin - This section will describe Automoto's services, including garage discovery, bundle purchases, and redemption process.]
                  </p>
                </section>
                
                <section>
                  <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                    3. User Accounts and Registration
                  </h2>
                  <p className="text-gray-600 leading-relaxed">
                    [Content to be added by admin - This section will cover account creation requirements, user responsibilities, and account security.]
                  </p>
                </section>
                
                <section>
                  <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                    4. Payment and Refunds
                  </h2>
                  <p className="text-gray-600 leading-relaxed">
                    [Content to be added by admin - This section will detail payment processing, bundle purchases, refund policies, and pricing.]
                  </p>
                </section>
                
                <section>
                  <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                    5. User Conduct and Prohibited Activities
                  </h2>
                  <p className="text-gray-600 leading-relaxed">
                    [Content to be added by admin - This section will outline acceptable use policies, prohibited activities, and consequences for violations.]
                  </p>
                </section>
                
                <section>
                  <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                    6. Vendor Relationships
                  </h2>
                  <p className="text-gray-600 leading-relaxed">
                    [Content to be added by admin - This section will clarify the relationship between users, Automoto, and service providers.]
                  </p>
                </section>
                
                <section>
                  <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                    7. Limitation of Liability
                  </h2>
                  <p className="text-gray-600 leading-relaxed">
                    [Content to be added by admin - This section will outline Automoto's liability limitations and user responsibilities.]
                  </p>
                </section>
                
                <section>
                  <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                    8. Contact Information
                  </h2>
                  <p className="text-gray-600 leading-relaxed">
                    If you have any questions about these Terms of Service, please contact us at:
                  </p>
                  <div className="bg-gray-50 p-6 rounded-xl mt-4">
                    <p className="text-gray-700">
                      <strong>Email:</strong> legal@automoto.ae<br />
                      <strong>Address:</strong> [To be added]<br />
                      <strong>Phone:</strong> [To be added]
                    </p>
                  </div>
                </section>
              </div>
              
              <div className="mt-12 p-6 bg-primary/5 rounded-xl border-l-4 border-primary">
                <p className="text-gray-700">
                  <strong>Note:</strong> These terms are currently being finalized. Please check back for the complete version or contact us for specific questions about our policies.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Terms;